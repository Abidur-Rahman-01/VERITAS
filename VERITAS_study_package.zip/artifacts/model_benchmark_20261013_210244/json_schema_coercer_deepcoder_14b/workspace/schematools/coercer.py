"""Type Coercion."""

def coerce_value(val, target_type: str):
    """Coerce string/primitive val to target_type ('int', 'float', 'bool', 'str')."""
    if val is None:
        return None
    if target_type == "str":
        return str(val)
    if target_type == "int":
        return int(val)
    if target_type == "float":
        return float(val)
    if target_type == "bool":
        # BUG: Direct bool(val) evaluates non-empty strings like 'false', '0', 'no' as True
        # Convert string literals to bool
        if isinstance(val, str):
            val = val.strip().lower()
            if val in ('true', '1', 'yes'):
                return True
            elif val in ('false', '0', 'no'):
                return False
        # Convert string literals to bool
        if isinstance(val, str):
            val = val.strip().lower()
            if val in ('true', '1', 'yes'):
                return True
            elif val in ('false', '0', 'no'):
                return False
        # Convert string literals to bool
        if isinstance(val, str):
            val = val.strip().lower()
            if val in ('true', '1', 'yes'):
                return True
            elif val in ('false', '0', 'no'):
                return False
        # Convert string literals to bool
        if isinstance(val, str):
            val = val.strip().lower()
            if val in ('true', '1', 'yes'):
                return True
            elif val in ('false', '0', 'no'):
                return False
        return bool(val)
    raise ValueError(f"Unknown target type: {target_type}")
