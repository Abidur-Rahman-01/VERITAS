"""Write a function to remove lowercase substrings from a given string."""

def remove_lowercase(str1):
    pass
