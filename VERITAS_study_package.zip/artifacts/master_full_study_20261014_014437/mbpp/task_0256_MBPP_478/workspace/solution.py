"""Write a function to remove lowercase substrings from a given string."""

def remove_lowercase(str1):
    if not isinstance(str1, str):
        raise TypeError("Input must be a string")
    
    result = ""
    for char in str1:
        if char.isupper():
            result += char
    return result
