"""Write a function to check whether the entered number is greater than the elements of the given array."""

def check_greater(arr, number):
    if not arr:
        return True
    for element in arr:
        if number <= element:
            return False
    return True
