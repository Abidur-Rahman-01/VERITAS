"""Write a function to remove uppercase substrings from a given string."""

def remove_uppercase(str1):
    if str1 is None:
        return None
    return ''.join(char for char in str1 if not char.isupper())
