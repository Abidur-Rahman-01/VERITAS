"""Write a function to remove uppercase substrings from a given string."""

def remove_uppercase(str1):
    pass
