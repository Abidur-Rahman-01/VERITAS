"""Write a function to extract specified size of strings from a given list of string values."""

def extract_string(str, l):
    if not str:
        return []
    return [s for s in str if len(s) == l]
