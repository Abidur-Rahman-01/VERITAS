"""Write a python function to check whether the given list contains consecutive numbers or not."""

def check_Consecutive(l):
    if not l:
        return True
    
    # Check if all elements are unique
    if len(l) != len(set(l)):
        return False
    
    # Get min and max values
    min_val = min(l)
    max_val = max(l)
    
    # For consecutive numbers, the difference between max and min should be equal to the length minus 1
    # and all numbers in range should be present
    expected_set = set(range(min_val, max_val + 1))
    actual_set = set(l)
    
    return expected_set == actual_set
