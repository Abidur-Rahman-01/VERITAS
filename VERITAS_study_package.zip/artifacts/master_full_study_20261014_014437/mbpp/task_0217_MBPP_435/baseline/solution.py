"""Write a python function to find the last digit of a given number."""

# Implement your function here:
