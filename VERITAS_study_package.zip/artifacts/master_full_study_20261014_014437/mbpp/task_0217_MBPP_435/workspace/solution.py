"""Write a python function to find the last digit of a given number."""

def last_Digit(n):
    return abs(n) % 10
