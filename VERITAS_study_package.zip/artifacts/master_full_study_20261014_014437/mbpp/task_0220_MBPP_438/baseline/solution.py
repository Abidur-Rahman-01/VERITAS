"""Write a function to count bidirectional tuple pairs."""

def count_bidirectional(test_list):
    pass
