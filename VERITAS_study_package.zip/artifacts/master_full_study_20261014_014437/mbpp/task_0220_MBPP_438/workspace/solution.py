"""Write a function to count bidirectional tuple pairs."""

def count_bidirectional(test_list):
    # Handle empty list case
    if not test_list:
        return 0
    
    # Create a set to store unique tuples
    tuple_set = set()
    # Counter for bidirectional pairs
    count = 0
    
    for tuple_item in test_list:
        # Create a sorted version of the tuple to identify bidirectional pairs
        sorted_tuple = tuple(sorted(tuple_item))
        
        # If we've seen this sorted tuple before, increment count
        if sorted_tuple in tuple_set:
            count += 1
        
        # Add the sorted tuple to our set
        tuple_set.add(sorted_tuple)
    
    return count
