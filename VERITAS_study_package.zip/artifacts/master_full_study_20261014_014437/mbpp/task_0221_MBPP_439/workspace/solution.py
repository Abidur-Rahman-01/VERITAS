"""Write a function to join a list of multiple integers into a single integer."""

def multiple_to_single(L):
    if not L:
        raise ValueError("Empty list not allowed")
    return int(''.join(map(str, L)))
