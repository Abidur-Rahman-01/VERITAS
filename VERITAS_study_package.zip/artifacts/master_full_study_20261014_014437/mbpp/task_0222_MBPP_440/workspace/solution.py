"""Write a function to find the first adverb and their positions in a given sentence."""

def find_adverb_position(text):
    # Handle empty or whitespace-only text
    if not text or not text.strip():
        return None
    
    # Split the text into words
    words = text.split()
    
    # Iterate through each word to find adverbs
    for i, word in enumerate(words):
        # Remove punctuation from the word for checking
        clean_word = ''.join(char for char in word if char.isalpha())
        
        # Check if the word ends with 'ly' (common adverb suffix)
        if clean_word.endswith('ly'):
            # Find the start position of this word in the original text
            start_pos = text.find(word)
            # Return the position, length, and the adverb itself
            return (start_pos, len(word), clean_word)
    
    # If no adverb found, return None
    return None
