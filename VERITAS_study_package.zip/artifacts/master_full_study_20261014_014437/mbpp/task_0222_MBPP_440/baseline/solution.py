"""Write a function to find the first adverb and their positions in a given sentence."""

def find_adverb_position(text):
    pass
