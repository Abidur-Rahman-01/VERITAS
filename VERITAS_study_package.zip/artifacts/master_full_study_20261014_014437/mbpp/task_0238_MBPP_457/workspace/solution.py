"""Write a python function to find the sublist having minimum length."""

def Find_Min(lst):
    if not lst:
        return None
    min_len = float('inf')
    min_sublist = None
    for sublist in lst:
        if len(sublist) < min_len:
            min_len = len(sublist)
            min_sublist = sublist
    return min_sublist
