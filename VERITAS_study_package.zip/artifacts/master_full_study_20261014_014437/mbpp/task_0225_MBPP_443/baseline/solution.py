"""Write a python function to find the largest negative number from the given list."""

def largest_neg(list1):
    pass
