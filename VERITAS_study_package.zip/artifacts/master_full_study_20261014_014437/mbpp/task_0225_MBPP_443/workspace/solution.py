"""Write a python function to find the largest negative number from the given list."""

def largest_neg(list1):
    negative_numbers = [num for num in list1 if num < 0]
    if not negative_numbers:
        return None
    return max(negative_numbers)
