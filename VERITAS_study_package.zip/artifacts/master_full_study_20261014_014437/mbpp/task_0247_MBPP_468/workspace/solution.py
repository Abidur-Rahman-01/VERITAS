"""Write a function to find the maximum product formed by multiplying numbers of an increasing subsequence of that array."""

def max_product(arr):
    if not arr:
        return 0
    
    n = len(arr)
    # dp[i] stores the maximum product of increasing subsequence ending at index i
    dp = [0] * n
    
    # Initialize each element as a subsequence of length 1
    for i in range(n):
        dp[i] = arr[i]
    
    # Fill dp array using dynamic programming
    for i in range(1, n):
        for j in range(i):
            if arr[i] > arr[j]:
                dp[i] = max(dp[i], dp[j] * arr[i])
    
    # Return the maximum value in dp array
    return max(dp)
