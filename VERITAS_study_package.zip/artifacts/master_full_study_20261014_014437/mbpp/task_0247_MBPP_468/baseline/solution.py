"""Write a function to find the maximum product formed by multiplying numbers of an increasing subsequence of that array."""

def max_product(arr):
    pass
