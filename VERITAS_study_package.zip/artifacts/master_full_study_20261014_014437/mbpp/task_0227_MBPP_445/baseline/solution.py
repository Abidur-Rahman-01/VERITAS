"""Write a function to perform index wise multiplication of tuple elements in the given two tuples."""

def index_multiplication(test_tup1, test_tup2):
    pass
