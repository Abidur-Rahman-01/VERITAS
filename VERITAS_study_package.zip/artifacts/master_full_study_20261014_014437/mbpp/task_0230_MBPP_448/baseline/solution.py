"""Write a function to calculate the sum of perrin numbers."""

def cal_sum(n):
    pass
