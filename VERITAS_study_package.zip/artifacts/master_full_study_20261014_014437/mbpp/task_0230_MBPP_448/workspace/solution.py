"""Write a function to calculate the sum of perrin numbers."""

def cal_sum(n):
    if n <= 0:
        return 0
    
    # Perrin sequence: P(0)=3, P(1)=0, P(2)=2, P(n) = P(n-2) + P(n-3)
    perrin = [3, 0, 2]
    
    # Generate the sequence up to n
    for i in range(3, n):
        next_val = perrin[i-2] + perrin[i-3]
        perrin.append(next_val)
    
    # Return sum of first n Perrin numbers
    return sum(perrin[:n])
