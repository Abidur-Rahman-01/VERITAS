"""Write a function to drop empty items from a given dictionary."""

def drop_empty(dict1):
    pass
