"""Write a function to drop empty items from a given dictionary."""

def drop_empty(dict1):
    if not dict1:
        return {}
    return {k: v for k, v in dict1.items() if v is not None}
