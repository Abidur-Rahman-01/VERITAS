"""Write a python function to return the negative numbers in a list."""

def neg_nos(list1):
    if not list1:
        return []
    return [num for num in list1 if num < 0]
