"""Write a python function to return the negative numbers in a list."""

def neg_nos(list1):
    pass
