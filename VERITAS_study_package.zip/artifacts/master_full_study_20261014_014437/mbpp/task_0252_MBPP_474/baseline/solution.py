"""Write a function to replace characters in a string."""

def replace_char(str1,ch,newch):
    pass
