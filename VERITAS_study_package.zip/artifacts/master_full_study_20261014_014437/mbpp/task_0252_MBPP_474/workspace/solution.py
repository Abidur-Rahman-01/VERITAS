"""Write a function to replace characters in a string."""

def replace_char(str1,ch,newch):
    if ch not in str1:
        return str1
    return str1.replace(ch, newch)
