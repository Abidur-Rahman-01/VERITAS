"""Write a function to find the area of a rectangle."""

def rectangle_area(l,b):
    if l == 0 or b == 0:
        return 0
    return l * b
