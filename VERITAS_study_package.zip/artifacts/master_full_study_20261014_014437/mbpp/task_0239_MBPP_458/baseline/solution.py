"""Write a function to find the area of a rectangle."""

def rectangle_area(l,b):
    pass
