"""Write a python function to find the first digit of a given number."""

def first_Digit(n):
    # Convert the number to string to easily access the first digit
    # Handle negative numbers by taking absolute value
    return int(str(abs(n))[0])
