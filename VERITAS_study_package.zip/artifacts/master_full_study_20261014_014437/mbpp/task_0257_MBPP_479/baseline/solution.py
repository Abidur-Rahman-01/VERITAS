"""Write a python function to find the first digit of a given number."""

# Implement your function here:
