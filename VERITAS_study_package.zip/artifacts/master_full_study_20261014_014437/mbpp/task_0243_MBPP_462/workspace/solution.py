"""Write a function to find all possible combinations of the elements of a given list."""

def combinations_list(list1):
    from itertools import combinations
    result = []
    for i in range(len(list1) + 1):
        for combo in combinations(list1, i):
            result.append(list(combo))
    return result
