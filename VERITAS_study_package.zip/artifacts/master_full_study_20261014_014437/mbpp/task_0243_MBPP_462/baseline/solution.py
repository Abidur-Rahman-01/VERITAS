"""Write a function to find all possible combinations of the elements of a given list."""

def combinations_list(list1):
    pass
