"""Write a python function to get the first element of each sublist."""

def Extract(lst):
    pass
