"""Write a python function to get the first element of each sublist."""

def Extract(lst):
    result = []
    for sublist in lst:
        if sublist:  # Check if sublist is not empty
            result.append(sublist[0])
    return result
