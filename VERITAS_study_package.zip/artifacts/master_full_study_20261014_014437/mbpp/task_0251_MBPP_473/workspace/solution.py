"""Write a function to find the tuple intersection of elements in the given tuple list irrespective of their order."""

def tuple_intersection(test_list1, test_list2):
    # Convert tuples to sets of frozensets for comparison
    # This allows us to ignore order within tuples
    set1 = {frozenset(t) for t in test_list1}
    set2 = {frozenset(t) for t in test_list2}
    
    # Find intersection of the sets
    intersection = set1 & set2
    
    # Convert back to tuple format
    result = set()
    for frozenset_item in intersection:
        # Convert frozenset back to tuple, maintaining original tuple structure
        # Since frozensets are unordered, we sort the elements to ensure consistent representation
        result.add(tuple(sorted(frozenset_item)))
    
    return result
