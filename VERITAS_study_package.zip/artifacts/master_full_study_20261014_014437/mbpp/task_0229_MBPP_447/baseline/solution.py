"""Write a function to find cubes of individual elements in a list."""

def cube_nums(nums):
    pass
