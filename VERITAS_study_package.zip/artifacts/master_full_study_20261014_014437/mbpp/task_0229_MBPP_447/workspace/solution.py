"""Write a function to find cubes of individual elements in a list."""

def cube_nums(nums):
    if not nums:
        return []
    return [num ** 3 for num in nums]
