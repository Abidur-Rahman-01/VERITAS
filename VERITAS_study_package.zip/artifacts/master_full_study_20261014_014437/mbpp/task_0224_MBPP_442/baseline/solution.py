"""Write a function to find the ration of positive numbers in an array of integers."""

def positive_count(nums):
    pass
