"""Write a function to find the ration of positive numbers in an array of integers."""

def positive_count(nums):
    if not nums:
        return 0
    positive = sum(1 for num in nums if num > 0)
    return round(positive / len(nums), 2)
