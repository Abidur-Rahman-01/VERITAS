"""Write a function to check if all values are same in a dictionary."""

def check_value(dict, n):
    if not dict:
        return False
    return all(value == n for value in dict.values())
