"""Write a function to remove odd characters in a string."""

def remove_odd(str1):
    pass
