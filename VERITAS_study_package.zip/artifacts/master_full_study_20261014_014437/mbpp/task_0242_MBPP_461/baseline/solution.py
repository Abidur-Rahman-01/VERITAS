"""Write a python function to count the upper case characters in a given string."""

def upper_ctr(str):
    pass
