"""Write a python function to count the upper case characters in a given string."""

def upper_ctr(str):
    count = 0
    for char in str:
        if char.isupper():
            count += 1
    return count
