"""Write a function to find the pairwise addition of the neighboring elements of the given tuple."""

def add_pairwise(test_tup):
    pass
