"""Write a function to find the pairwise addition of the neighboring elements of the given tuple."""

def add_pairwise(test_tup):
    if len(test_tup) <= 1:
        return ()
    return tuple(test_tup[i] + test_tup[i+1] for i in range(len(test_tup)-1))
