"""Write a python function to count the occurence of all elements of list in a tuple."""

def count_Occurrence(tup, lst):
    count = 0
    for element in lst:
        count += tup.count(element)
    return count
