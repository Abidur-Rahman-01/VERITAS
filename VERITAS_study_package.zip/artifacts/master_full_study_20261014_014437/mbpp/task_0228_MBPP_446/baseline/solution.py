"""Write a python function to count the occurence of all elements of list in a tuple."""

def count_Occurrence(tup, lst):
    pass
