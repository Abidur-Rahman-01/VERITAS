"""Write a function to find the surface area of a cube of a given size."""

def surfacearea_cube(l):
    pass
