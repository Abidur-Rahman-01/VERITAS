"""Write a function to find the surface area of a cube of a given size."""

def surfacearea_cube(l):
    if not isinstance(l, (int, float)) or l <= 0:
        raise ValueError("The length must be a positive number.")
    return 6 * l ** 2
