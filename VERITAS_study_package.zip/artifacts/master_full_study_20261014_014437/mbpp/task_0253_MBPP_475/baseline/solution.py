"""Write a function to sort a dictionary by value."""

def sort_counter(dict1):
    pass
