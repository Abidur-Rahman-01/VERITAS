"""Write a function to sort a dictionary by value."""

def sort_counter(dict1):
    if not dict1:
        return []
    return sorted(dict1.items(), key=lambda item: item[1], reverse=True)
