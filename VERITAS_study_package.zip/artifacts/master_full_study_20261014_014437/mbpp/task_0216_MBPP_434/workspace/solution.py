"""Write a function that matches a string that has an a followed by one or more b's."""

import re

def text_match_one(text):
    if not text:
        return False
    pattern = '^a+b+$'
    return bool(re.match(pattern, text))
