"""Write a function that matches a string that has an a followed by one or more b's."""

def text_match_one(text):
    pass
