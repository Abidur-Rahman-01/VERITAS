"""Write a function that gives loss amount on a sale if the given amount has loss else return 0."""

def loss_amount(actual_cost,sale_amount):
    if actual_cost > sale_amount:
        return actual_cost - sale_amount
    else:
        return 0
