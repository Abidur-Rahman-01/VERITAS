"""Write a function to find the maximum product subarray of the given array."""

def max_subarray_product(arr):
    if not arr:
        return 0
    
    max_product = arr[0]
    min_product = arr[0]
    result = arr[0]
    
    for i in range(1, len(arr)):
        current = arr[i]
        
        # When we encounter a zero, reset the products
        if current == 0:
            max_product = 0
            min_product = 0
            result = max(result, 0)
            continue
        
        # When we encounter a negative number, max and min swap roles
        if current < 0:
            max_product, min_product = min_product, max_product
        
        # Calculate new max and min products ending at current position
        max_product = max(current, max_product * current)
        min_product = min(current, min_product * current)
        
        # Update the overall result
        result = max(result, max_product)
    
    return result
