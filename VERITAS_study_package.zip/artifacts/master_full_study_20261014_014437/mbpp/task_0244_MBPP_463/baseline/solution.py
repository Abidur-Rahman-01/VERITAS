"""Write a function to find the maximum product subarray of the given array."""

def max_subarray_product(arr):
    pass
