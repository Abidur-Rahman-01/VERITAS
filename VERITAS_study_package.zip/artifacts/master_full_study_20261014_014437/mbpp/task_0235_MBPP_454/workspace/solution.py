"""Write a function that matches a word containing 'z'."""

import re

def text_match_wordz(text):
    # Handle edge cases
    if not isinstance(text, str) or text is None:
        return False
    
    # Use regex to find words containing 'z'
    pattern = r'\b\w*z\w*\b'
    return bool(re.search(pattern, text))
