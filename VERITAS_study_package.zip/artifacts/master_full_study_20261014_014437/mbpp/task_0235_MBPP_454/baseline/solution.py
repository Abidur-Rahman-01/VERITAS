"""Write a function that matches a word containing 'z'."""

def text_match_wordz(text):
    pass
