"""Write a python function to find the product of the array multiplication modulo n."""

def find_remainder(arr, n):
    pass
