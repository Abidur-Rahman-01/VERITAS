"""Write a python function to find the product of the array multiplication modulo n."""

def find_remainder(arr, n):
    if not arr:
        return 0
    product = 1
    for num in arr:
        product = (product * num) % n
    return product
