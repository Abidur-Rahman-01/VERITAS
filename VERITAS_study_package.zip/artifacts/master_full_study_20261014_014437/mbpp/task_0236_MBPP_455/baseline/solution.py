"""Write a function to check whether the given month number contains 31 days or not."""

def check_monthnumb_number(monthnum2):
    pass
