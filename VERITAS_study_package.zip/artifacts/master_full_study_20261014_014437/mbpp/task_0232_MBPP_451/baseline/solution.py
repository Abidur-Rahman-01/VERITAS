"""Write a function to remove all whitespaces from the given string."""

def remove_whitespaces(text1):
    pass
