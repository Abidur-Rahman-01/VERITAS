"""Write a function to remove all whitespaces from the given string."""

def remove_whitespaces(text1):
    if text1 is None:
        return None
    return text1.replace(' ', '')
