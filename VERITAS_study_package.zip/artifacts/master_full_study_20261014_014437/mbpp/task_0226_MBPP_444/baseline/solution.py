"""Write a function to trim each tuple by k in the given tuple list."""

def trim_tuple(test_list, K):
    pass
