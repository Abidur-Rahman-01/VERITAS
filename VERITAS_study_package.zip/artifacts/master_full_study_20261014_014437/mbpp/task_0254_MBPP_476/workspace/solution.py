"""Write a python function to find the sum of the largest and smallest value in a given array."""

def big_sum(nums):
    if not nums:
        return None
    return min(nums) + max(nums)
