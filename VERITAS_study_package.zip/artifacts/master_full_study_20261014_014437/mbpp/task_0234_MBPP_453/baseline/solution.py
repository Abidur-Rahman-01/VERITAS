"""Write a python function to find the sum of even factors of a number."""

# Implement your function here:
