"""Write a python function to find the sum of even factors of a number."""

def sumofFactors(n):
    total = 0
    for i in range(1, n + 1):  # Check all numbers from 1 to n
        if n % i == 0 and i % 2 == 0:  # If i is a factor of n and i is even
            total += i
    return total
