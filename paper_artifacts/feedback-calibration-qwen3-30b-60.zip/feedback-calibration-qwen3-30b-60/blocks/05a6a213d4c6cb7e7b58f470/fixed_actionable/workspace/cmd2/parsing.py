"""Command line parser."""

def parse_command_line(cmd: str) -> tuple[str, str | None]:
    # Find the last '>' that is not inside quotes
    if '>' in cmd:
        # Count quotes to find the last '>' not inside quotes
        last_greater_than_index = -1
        in_single_quotes = False
        in_double_quotes = False
        
        for i, char in enumerate(cmd):
            if char == "'" and not in_double_quotes:
                in_single_quotes = not in_single_quotes
            elif char == '"' and not in_single_quotes:
                in_double_quotes = not in_double_quotes
            elif char == '>' and not in_single_quotes and not in_double_quotes:
                last_greater_than_index = i
        
        if last_greater_than_index != -1:
            before_redirect = cmd[:last_greater_than_index]
            after_redirect = cmd[last_greater_than_index + 1:]
            return before_redirect.strip(), after_redirect.strip()
    return cmd.strip(), None
