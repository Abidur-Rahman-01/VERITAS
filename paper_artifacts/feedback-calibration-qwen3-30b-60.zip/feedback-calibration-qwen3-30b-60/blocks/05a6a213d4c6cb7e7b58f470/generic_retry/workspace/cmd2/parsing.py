"""Command line parser."""

def parse_command_line(cmd: str) -> tuple[str, str | None]:
    # Find the last '>' that is not inside quotes
    if '>' in cmd:
        # Use a more robust approach to find '>' not inside quotes
        # We'll iterate through the string and track quote nesting
        in_single_quote = False
        in_double_quote = False
        last_unquoted_gt = -1
        
        for i, char in enumerate(cmd):
            if char == "'" and not in_double_quote:
                in_single_quote = not in_single_quote
            elif char == '"' and not in_single_quote:
                in_double_quote = not in_double_quote
            elif char == '>' and not in_single_quote and not in_double_quote:
                last_unquoted_gt = i
        
        if last_unquoted_gt != -1:
            before_redirect = cmd[:last_unquoted_gt]
            after_redirect = cmd[last_unquoted_gt+1:]
            
            return before_redirect.strip(), after_redirect.strip()
    
    return cmd.strip(), None
