"""Command line parser."""

def parse_command_line(cmd: str) -> tuple[str, str | None]:
    # Find the last '>' that is not inside quotes
    if '>' in cmd:
        # Split from the right to find the last '>' not inside quotes
        parts = cmd.rsplit('>', 1)
        # Check if the part after '>' is inside quotes
        before_redirect = parts[0]
        after_redirect = parts[1]
        
        # If the part after '>' is inside quotes, don't split
        if (after_redirect.startswith("'") and after_redirect.endswith("'")) or \
           (after_redirect.startswith('"') and after_redirect.endswith('"')):
            return cmd.strip(), None
        
        return before_redirect.strip(), after_redirect.strip()
    return cmd.strip(), None
