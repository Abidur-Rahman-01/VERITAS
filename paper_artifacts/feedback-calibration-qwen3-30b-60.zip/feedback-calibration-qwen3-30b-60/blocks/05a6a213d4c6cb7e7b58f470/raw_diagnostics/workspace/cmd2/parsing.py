"""Command line parser."""

def parse_command_line(cmd: str) -> tuple[str, str | None]:
    # Find the last '>' that is not inside quotes
    if '>' in cmd:
        # Split from the right to find the last '>' not inside quotes
        parts = cmd.rsplit('>', 1)
        before_redirect = parts[0]
        after_redirect = parts[1]
        
        # Check if the part after '>' is inside quotes
        # If it starts and ends with same quote type, it's quoted
        if (after_redirect.startswith("'") and after_redirect.endswith("'") or \
            after_redirect.startswith('"') and after_redirect.endswith('"')):
            return cmd.strip(), None
        
        # Check if the '>' is inside quotes in the before_redirect part
        # Simple approach: check if there are unmatched quotes in before_redirect
        quote_count = 0
        in_single_quote = False
        in_double_quote = False
        for char in before_redirect:
            if char == "'" and not in_double_quote:
                in_single_quote = not in_single_quote
            elif char == '"' and not in_single_quote:
                in_double_quote = not in_double_quote
        
        # If we're inside quotes, don't split
        if in_single_quote or in_double_quote:
            return cmd.strip(), None
        
        return before_redirect.strip(), after_redirect.strip()
    return cmd.strip(), None
