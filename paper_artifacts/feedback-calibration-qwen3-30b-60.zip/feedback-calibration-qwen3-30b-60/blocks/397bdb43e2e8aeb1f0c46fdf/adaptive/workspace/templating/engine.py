"""Template Engine."""
import re

def render_template(template: str, context: dict) -> str:
    # FIX: Use .get() to default to empty string when key is missing
    def replacer(match):
        key = match.group(1).strip()
        return str(context.get(key, ""))
    return re.sub(r"\{\{\s*(\w+)\s*\}\}", replacer, template)
